package com.lcj.web.service.car.impl;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.lcj.web.entity.car.MessagePackageNo;
import com.lcj.web.mapper.car.MessagePackageNoMapper;
import com.lcj.web.service.car.MessagePackageNoService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 消息包编号表 服务实现类
 * </p>
 *
 * @author lcj
 * @since 2017-09-25
 */
@Service
public class MessagePackageNoServiceImpl  implements MessagePackageNoService {
	@Autowired
	private MessagePackageNoMapper messagePackageNoMapper;
	
	public void insert(MessagePackageNo messagePackageNo){
		messagePackageNoMapper.insert(messagePackageNo);
	}

	@Override
	public MessagePackageNo selectOne(Wrapper<MessagePackageNo> eq) {
		// TODO Auto-generated method stub
		return null;
	}
}

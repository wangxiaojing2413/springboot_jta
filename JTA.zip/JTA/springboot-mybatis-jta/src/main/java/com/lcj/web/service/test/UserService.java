package com.lcj.web.service.test;

import com.lcj.web.entity.test.User;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author lcj
 * @since 2017-09-27
 */
public interface UserService{
	void insert(User user);
}

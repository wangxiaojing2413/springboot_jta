### 项目使用到的技术如下:
- spring boot
- mybatis
- jta (分布式事务)
- druid (多数据源)